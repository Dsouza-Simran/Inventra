import { useInventory } from '@/hooks/useInventory';
import { chartData, categoryDistribution } from '@/lib/data';
import { Package, Warehouse, AlertTriangle, TrendingUp, XCircle } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

function StatCard({ label, value, change, icon: Icon, variant = 'default' }: { label: string; value: string | number; change?: string; icon: React.ElementType; variant?: 'default' | 'warning' }) {
  return (
    <div className="rounded-xl border border-border bg-card p-5 shadow-inventra">
      <div className="flex items-center justify-between">
        <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">{label}</p>
        <div className={`flex h-8 w-8 items-center justify-center rounded-lg ${variant === 'warning' ? 'bg-destructive/10' : 'bg-primary/10'}`}>
          <Icon className={`h-4 w-4 ${variant === 'warning' ? 'text-destructive' : 'text-primary'}`} />
        </div>
      </div>
      <div className="mt-2 flex items-baseline gap-2">
        <h2 className={`text-2xl font-bold ${variant === 'warning' ? 'text-destructive' : 'text-foreground'}`}>{value}</h2>
        {change && <span className="text-xs font-medium text-success">{change}</span>}
      </div>
    </div>
  );
}

export default function DashboardPage() {
  const { products, warehouses, ledger } = useInventory();
  const lowStock = products.filter(p => p.totalStock > 0 && p.totalStock <= p.reorderLevel);
  const outOfStock = products.filter(p => p.totalStock === 0);
  const totalItems = products.reduce((sum, p) => sum + p.totalStock, 0);

  return (
    <div className="space-y-6 p-6 lg:p-8">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Dashboard</h1>
        <p className="text-sm text-muted-foreground">Inventory at the speed of thought.</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-5">
        <StatCard label="Total Products" value={products.length} change="+12%" icon={Package} />
        <StatCard label="Low Stock" value={lowStock.length} icon={AlertTriangle} variant="warning" />
        <StatCard label="Out of Stock" value={outOfStock.length} icon={XCircle} variant="warning" />
        <StatCard label="Warehouses" value={warehouses.length} icon={Warehouse} />
        <StatCard label="Total Items" value={totalItems.toLocaleString()} change="+8%" icon={TrendingUp} />
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        {/* Line chart */}
        <div className="lg:col-span-2 rounded-xl border border-border bg-card p-5 shadow-inventra">
          <h3 className="mb-4 text-sm font-medium text-muted-foreground">Stock Movement (7 Days)</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(214, 32%, 91%)" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 12 }} />
                <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12 }} />
                <Tooltip contentStyle={{ borderRadius: '8px', border: '1px solid hsl(214, 32%, 91%)', boxShadow: '0 4px 12px rgba(0,0,0,0.08)' }} />
                <Line type="monotone" dataKey="in" stroke="hsl(221, 83%, 53%)" strokeWidth={2} dot={false} name="Stock In" />
                <Line type="monotone" dataKey="out" stroke="hsl(0, 84%, 60%)" strokeWidth={2} dot={false} name="Stock Out" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Pie chart */}
        <div className="rounded-xl border border-border bg-card p-5 shadow-inventra">
          <h3 className="mb-4 text-sm font-medium text-muted-foreground">By Category</h3>
          <div className="h-52">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={categoryDistribution} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} strokeWidth={2} stroke="hsl(0, 0%, 100%)">
                  {categoryDistribution.map((entry, i) => <Cell key={i} fill={entry.fill} />)}
                </Pie>
                <Tooltip contentStyle={{ borderRadius: '8px', border: '1px solid hsl(214, 32%, 91%)' }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-2 space-y-1">
            {categoryDistribution.map(c => (
              <div key={c.name} className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <div className="h-2 w-2 rounded-full" style={{ background: c.fill }} />
                  <span className="text-muted-foreground">{c.name}</span>
                </div>
                <span className="font-medium text-foreground">{c.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="rounded-xl border border-border bg-card p-5 shadow-inventra">
        <h3 className="mb-4 text-sm font-medium text-muted-foreground">Recent Activity</h3>
        <div className="space-y-3">
          {ledger.slice(0, 6).map(entry => (
            <div key={entry.id} className="flex items-center justify-between rounded-lg border border-border p-3">
              <div>
                <p className="text-sm font-medium text-foreground">{entry.productName}</p>
                <p className="text-xs text-muted-foreground">{entry.warehouseName} · {entry.note}</p>
              </div>
              <div className="text-right">
                <span className={`inline-flex items-center rounded-md px-2 py-0.5 text-xs font-semibold ${
                  entry.type === 'IN' ? 'bg-success/10 text-success' :
                  entry.type === 'OUT' ? 'bg-destructive/10 text-destructive' :
                  entry.type === 'TRANSFER' ? 'bg-primary/10 text-primary' :
                  'bg-warning/10 text-warning'
                }`}>
                  {entry.type === 'IN' ? '+' : entry.type === 'OUT' ? '-' : ''}{entry.quantity} {entry.type}
                </span>
                <p className="mt-0.5 text-xs text-muted-foreground">{new Date(entry.date).toLocaleDateString()}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
