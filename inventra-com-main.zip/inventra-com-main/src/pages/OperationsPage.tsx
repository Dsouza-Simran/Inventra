import { useState } from 'react';
import { useInventory } from '@/hooks/useInventory';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { ArrowDownToLine, ArrowUpFromLine, ArrowLeftRight, SlidersHorizontal } from 'lucide-react';
import { toast } from 'sonner';

const opTypes = [
  { value: 'IN', label: 'Receive Stock', icon: ArrowDownToLine, desc: 'Add incoming inventory' },
  { value: 'OUT', label: 'Deliver Stock', icon: ArrowUpFromLine, desc: 'Ship outgoing inventory' },
  { value: 'TRANSFER', label: 'Transfer', icon: ArrowLeftRight, desc: 'Move between warehouses' },
  { value: 'ADJUST', label: 'Adjust', icon: SlidersHorizontal, desc: 'Manual stock adjustment' },
] as const;

export default function OperationsPage() {
  const { products, warehouses, adjustStock } = useInventory();
  const [type, setType] = useState<'IN' | 'OUT' | 'TRANSFER' | 'ADJUST'>('IN');
  const [productId, setProductId] = useState('');
  const [warehouseId, setWarehouseId] = useState('');
  const [toWarehouseId, setToWarehouseId] = useState('');
  const [quantity, setQuantity] = useState('');
  const [note, setNote] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!productId || !warehouseId || !quantity) { toast.error('Please fill all required fields.'); return; }
    if (type === 'TRANSFER' && !toWarehouseId) { toast.error('Select destination warehouse.'); return; }

    const product = products.find(p => p.id === productId);
    const warehouse = warehouses.find(w => w.id === warehouseId);
    const toWarehouse = warehouses.find(w => w.id === toWarehouseId);

    adjustStock({
      productId,
      productName: product?.name || '',
      warehouseId,
      warehouseName: warehouse?.name || '',
      toWarehouseId: toWarehouseId || undefined,
      toWarehouseName: toWarehouse?.name || undefined,
      type,
      quantity: type === 'ADJUST' ? +quantity : Math.abs(+quantity),
      note,
    });

    toast.success(`Stock ${type.toLowerCase()} recorded successfully.`);
    setProductId('');
    setQuantity('');
    setNote('');
  };

  return (
    <div className="space-y-6 p-6 lg:p-8">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Inventory Operations</h1>
        <p className="text-sm text-muted-foreground">Record stock movements</p>
      </div>

      {/* Type selector */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {opTypes.map(op => (
          <button
            key={op.value}
            onClick={() => setType(op.value)}
            className={`rounded-xl border p-4 text-left transition-colors ${type === op.value ? 'border-primary bg-primary/5' : 'border-border bg-card hover:bg-secondary/50'}`}
          >
            <op.icon className={`h-5 w-5 ${type === op.value ? 'text-primary' : 'text-muted-foreground'}`} />
            <p className={`mt-2 text-sm font-semibold ${type === op.value ? 'text-primary' : 'text-foreground'}`}>{op.label}</p>
            <p className="text-xs text-muted-foreground">{op.desc}</p>
          </button>
        ))}
      </div>

      {/* Form */}
      <form onSubmit={handleSubmit} className="max-w-lg space-y-4 rounded-xl border border-border bg-card p-6 shadow-inventra">
        <div className="space-y-2">
          <Label>Product *</Label>
          <Select value={productId} onValueChange={setProductId}>
            <SelectTrigger><SelectValue placeholder="Select product" /></SelectTrigger>
            <SelectContent>{products.map(p => <SelectItem key={p.id} value={p.id}>{p.name} ({p.sku})</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label>{type === 'TRANSFER' ? 'From Warehouse *' : 'Warehouse *'}</Label>
          <Select value={warehouseId} onValueChange={setWarehouseId}>
            <SelectTrigger><SelectValue placeholder="Select warehouse" /></SelectTrigger>
            <SelectContent>{warehouses.map(w => <SelectItem key={w.id} value={w.id}>{w.name}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        {type === 'TRANSFER' && (
          <div className="space-y-2">
            <Label>To Warehouse *</Label>
            <Select value={toWarehouseId} onValueChange={setToWarehouseId}>
              <SelectTrigger><SelectValue placeholder="Select destination" /></SelectTrigger>
              <SelectContent>{warehouses.filter(w => w.id !== warehouseId).map(w => <SelectItem key={w.id} value={w.id}>{w.name}</SelectItem>)}</SelectContent>
            </Select>
          </div>
        )}
        <div className="space-y-2">
          <Label>Quantity *{type === 'ADJUST' && ' (negative to subtract)'}</Label>
          <Input type="number" value={quantity} onChange={e => setQuantity(e.target.value)} placeholder="0" />
        </div>
        <div className="space-y-2">
          <Label>Note</Label>
          <Textarea value={note} onChange={e => setNote(e.target.value)} placeholder="Reason for this operation..." rows={2} />
        </div>
        <Button type="submit" className="w-full">Record {opTypes.find(o => o.value === type)?.label}</Button>
      </form>
    </div>
  );
}
