import { useState, useMemo } from 'react';
import { useInventory } from '@/hooks/useInventory';
import { CATEGORIES, type Product } from '@/lib/data';
import { Plus, Pencil, Trash2, Search, ArrowUpDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

export default function ProductsPage() {
  const { products, warehouses, ledger, addProduct, updateProduct, deleteProduct } = useInventory();
  const [search, setSearch] = useState('');
  const [catFilter, setCatFilter] = useState('all');
  const [whFilter, setWhFilter] = useState('all');
  const [sortStock, setSortStock] = useState<'none' | 'asc' | 'desc'>('none');
  const [editProduct, setEditProduct] = useState<Product | null>(null);
  const [isNew, setIsNew] = useState(false);

  // Map products to warehouses via ledger
  const productWarehouseMap = useMemo(() => {
    const map = new Map<string, Set<string>>();
    ledger.forEach(e => {
      if (!map.has(e.productId)) map.set(e.productId, new Set());
      map.get(e.productId)!.add(e.warehouseId);
    });
    return map;
  }, [ledger]);

  const filtered = useMemo(() => {
    let result = products.filter(p => {
      const matchSearch = p.name.toLowerCase().includes(search.toLowerCase()) || p.sku.toLowerCase().includes(search.toLowerCase());
      const matchCat = catFilter === 'all' || p.category === catFilter;
      const matchWh = whFilter === 'all' || (productWarehouseMap.get(p.id)?.has(whFilter) ?? false);
      return matchSearch && matchCat && matchWh;
    });
    if (sortStock === 'asc') result = [...result].sort((a, b) => a.totalStock - b.totalStock);
    if (sortStock === 'desc') result = [...result].sort((a, b) => b.totalStock - a.totalStock);
    return result;
  }, [products, search, catFilter, whFilter, sortStock, productWarehouseMap]);

  const blank: Product = { id: '', name: '', sku: '', category: 'Electronics', unit: 'pcs', reorderLevel: 10, totalStock: 0 };

  const handleSave = () => {
    if (!editProduct) return;
    if (isNew) addProduct(editProduct);
    else updateProduct(editProduct);
    setEditProduct(null);
  };

  return (
    <div className="space-y-6 p-6 lg:p-8">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Products</h1>
          <p className="text-sm text-muted-foreground">{products.length} products in inventory</p>
        </div>
        <Button onClick={() => { setIsNew(true); setEditProduct(blank); }}>
          <Plus className="mr-2 h-4 w-4" /> Add Product
        </Button>
      </div>

      {/* Filters */}
      <div className="flex flex-col gap-3 sm:flex-row sm:flex-wrap">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input placeholder="Search by name or SKU..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
        </div>
        <Select value={catFilter} onValueChange={setCatFilter}>
          <SelectTrigger className="w-full sm:w-44"><SelectValue placeholder="Category" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Categories</SelectItem>
            {CATEGORIES.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={whFilter} onValueChange={setWhFilter}>
          <SelectTrigger className="w-full sm:w-44"><SelectValue placeholder="Warehouse" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Warehouses</SelectItem>
            {warehouses.map(w => <SelectItem key={w.id} value={w.id}>{w.name}</SelectItem>)}
          </SelectContent>
        </Select>
        <Button variant="outline" size="sm" className="h-10" onClick={() => setSortStock(s => s === 'none' ? 'asc' : s === 'asc' ? 'desc' : 'none')}>
          <ArrowUpDown className="mr-2 h-4 w-4" />
          Stock {sortStock === 'asc' ? '↑' : sortStock === 'desc' ? '↓' : ''}
        </Button>
      </div>

      {/* Table */}
      <div className="overflow-x-auto rounded-xl border border-border bg-card shadow-inventra">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border">
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-muted-foreground">Product</th>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-muted-foreground">SKU</th>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-muted-foreground hidden sm:table-cell">Category</th>
              <th className="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wider text-muted-foreground">Stock</th>
              <th className="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wider text-muted-foreground hidden md:table-cell">Reorder</th>
              <th className="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wider text-muted-foreground">Actions</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map(p => (
              <tr key={p.id} className="border-b border-border last:border-0 hover:bg-secondary/50 transition-colors">
                <td className="px-4 py-3 font-medium text-foreground">
                  <span className="flex items-center gap-2">
                    {p.name}
                    {p.totalStock === 0 && <span className="inline-flex items-center rounded-full bg-destructive px-2 py-0.5 text-[10px] font-semibold text-destructive-foreground">Out of Stock</span>}
                    {p.totalStock > 0 && p.totalStock <= p.reorderLevel && <span className="inline-flex items-center rounded-full bg-destructive/15 px-2 py-0.5 text-[10px] font-semibold text-destructive">Low Stock</span>}
                  </span>
                </td>
                <td className="px-4 py-3 text-muted-foreground font-mono text-xs">{p.sku}</td>
                <td className="px-4 py-3 text-muted-foreground hidden sm:table-cell">{p.category}</td>
                <td className={`px-4 py-3 text-right font-semibold ${p.totalStock <= p.reorderLevel ? 'text-destructive' : 'text-foreground'}`}>
                  {p.totalStock} {p.unit}
                </td>
                <td className="px-4 py-3 text-right text-muted-foreground hidden md:table-cell">{p.reorderLevel}</td>
                <td className="px-4 py-3 text-right">
                  <div className="flex justify-end gap-1">
                    <button onClick={() => { setIsNew(false); setEditProduct(p); }} className="rounded-md p-1.5 text-muted-foreground hover:bg-secondary hover:text-foreground"><Pencil className="h-3.5 w-3.5" /></button>
                    <button onClick={() => deleteProduct(p.id)} className="rounded-md p-1.5 text-muted-foreground hover:bg-destructive/10 hover:text-destructive"><Trash2 className="h-3.5 w-3.5" /></button>
                  </div>
                </td>
              </tr>
            ))}
            {filtered.length === 0 && (
              <tr><td colSpan={6} className="px-4 py-8 text-center text-muted-foreground">No products found.</td></tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Dialog */}
      <Dialog open={!!editProduct} onOpenChange={open => !open && setEditProduct(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{isNew ? 'Add Product' : 'Edit Product'}</DialogTitle>
          </DialogHeader>
          {editProduct && (
            <div className="space-y-4">
              <div className="space-y-2"><Label>Name</Label><Input value={editProduct.name} onChange={e => setEditProduct({ ...editProduct, name: e.target.value })} /></div>
              <div className="space-y-2"><Label>SKU</Label><Input value={editProduct.sku} onChange={e => setEditProduct({ ...editProduct, sku: e.target.value })} /></div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Category</Label>
                  <Select value={editProduct.category} onValueChange={v => setEditProduct({ ...editProduct, category: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>{CATEGORIES.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <div className="space-y-2"><Label>Unit</Label><Input value={editProduct.unit} onChange={e => setEditProduct({ ...editProduct, unit: e.target.value })} /></div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2"><Label>Reorder Level</Label><Input type="number" value={editProduct.reorderLevel} onChange={e => setEditProduct({ ...editProduct, reorderLevel: +e.target.value })} /></div>
                {isNew && <div className="space-y-2"><Label>Initial Stock</Label><Input type="number" value={editProduct.totalStock} onChange={e => setEditProduct({ ...editProduct, totalStock: +e.target.value })} /></div>}
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditProduct(null)}>Cancel</Button>
            <Button onClick={handleSave}>{isNew ? 'Add' : 'Save'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
