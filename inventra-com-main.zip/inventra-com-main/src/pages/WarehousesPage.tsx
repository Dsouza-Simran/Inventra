import { useState } from 'react';
import { useInventory } from '@/hooks/useInventory';
import type { Warehouse } from '@/lib/data';
import { Plus, Pencil, Trash2, MapPin } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';

export default function WarehousesPage() {
  const { warehouses, addWarehouse, updateWarehouse, deleteWarehouse, products } = useInventory();
  const [editWh, setEditWh] = useState<Warehouse | null>(null);
  const [isNew, setIsNew] = useState(false);

  const blank: Warehouse = { id: '', name: '', location: '' };

  const handleSave = () => {
    if (!editWh) return;
    if (isNew) addWarehouse(editWh);
    else updateWarehouse(editWh);
    setEditWh(null);
  };

  return (
    <div className="space-y-6 p-6 lg:p-8">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Warehouses</h1>
          <p className="text-sm text-muted-foreground">{warehouses.length} locations</p>
        </div>
        <Button onClick={() => { setIsNew(true); setEditWh(blank); }}>
          <Plus className="mr-2 h-4 w-4" /> Add Warehouse
        </Button>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {warehouses.map(w => (
          <div key={w.id} className="rounded-xl border border-border bg-card p-5 shadow-inventra">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="text-base font-semibold text-foreground">{w.name}</h3>
                <div className="mt-1 flex items-center gap-1 text-xs text-muted-foreground">
                  <MapPin className="h-3 w-3" /> {w.location}
                </div>
              </div>
              <div className="flex gap-1">
                <button onClick={() => { setIsNew(false); setEditWh(w); }} className="rounded-md p-1.5 text-muted-foreground hover:bg-secondary hover:text-foreground"><Pencil className="h-3.5 w-3.5" /></button>
                <button onClick={() => deleteWarehouse(w.id)} className="rounded-md p-1.5 text-muted-foreground hover:bg-destructive/10 hover:text-destructive"><Trash2 className="h-3.5 w-3.5" /></button>
              </div>
            </div>
          </div>
        ))}
      </div>

      <Dialog open={!!editWh} onOpenChange={open => !open && setEditWh(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>{isNew ? 'Add Warehouse' : 'Edit Warehouse'}</DialogTitle></DialogHeader>
          {editWh && (
            <div className="space-y-4">
              <div className="space-y-2"><Label>Name</Label><Input value={editWh.name} onChange={e => setEditWh({ ...editWh, name: e.target.value })} /></div>
              <div className="space-y-2"><Label>Location</Label><Input value={editWh.location} onChange={e => setEditWh({ ...editWh, location: e.target.value })} /></div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditWh(null)}>Cancel</Button>
            <Button onClick={handleSave}>{isNew ? 'Add' : 'Save'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
