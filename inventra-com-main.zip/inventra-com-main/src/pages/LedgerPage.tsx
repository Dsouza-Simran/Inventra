import { useState } from 'react';
import { useInventory } from '@/hooks/useInventory';
import { Search } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const typeColors: Record<string, string> = {
  IN: 'bg-success/10 text-success',
  OUT: 'bg-destructive/10 text-destructive',
  TRANSFER: 'bg-primary/10 text-primary',
  ADJUST: 'bg-warning/10 text-warning',
};

export default function LedgerPage() {
  const { ledger } = useInventory();
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState('all');

  const filtered = ledger.filter(e => {
    const matchSearch = e.productName.toLowerCase().includes(search.toLowerCase()) || e.warehouseName.toLowerCase().includes(search.toLowerCase());
    const matchType = typeFilter === 'all' || e.type === typeFilter;
    return matchSearch && matchType;
  });

  return (
    <div className="space-y-6 p-6 lg:p-8">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Stock Ledger</h1>
        <p className="text-sm text-muted-foreground">Complete audit trail of all stock movements</p>
      </div>

      <div className="flex flex-col gap-3 sm:flex-row">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input placeholder="Search by product or warehouse..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
        </div>
        <Select value={typeFilter} onValueChange={setTypeFilter}>
          <SelectTrigger className="w-full sm:w-40"><SelectValue placeholder="Type" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Types</SelectItem>
            <SelectItem value="IN">Stock In</SelectItem>
            <SelectItem value="OUT">Stock Out</SelectItem>
            <SelectItem value="TRANSFER">Transfer</SelectItem>
            <SelectItem value="ADJUST">Adjustment</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="overflow-x-auto rounded-xl border border-border bg-card shadow-inventra">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border">
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-muted-foreground">Date</th>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-muted-foreground">Product</th>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-muted-foreground hidden sm:table-cell">Warehouse</th>
              <th className="px-4 py-3 text-center text-xs font-semibold uppercase tracking-wider text-muted-foreground">Type</th>
              <th className="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wider text-muted-foreground">Qty</th>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-muted-foreground hidden md:table-cell">Note</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map(e => (
              <tr key={e.id} className="border-b border-border last:border-0 hover:bg-secondary/50 transition-colors">
                <td className="px-4 py-3 text-muted-foreground text-xs whitespace-nowrap">{new Date(e.date).toLocaleString()}</td>
                <td className="px-4 py-3 font-medium text-foreground">{e.productName}</td>
                <td className="px-4 py-3 text-muted-foreground hidden sm:table-cell">
                  {e.warehouseName}{e.toWarehouseName ? ` → ${e.toWarehouseName}` : ''}
                </td>
                <td className="px-4 py-3 text-center">
                  <span className={`inline-flex rounded-md px-2 py-0.5 text-xs font-semibold ${typeColors[e.type]}`}>{e.type}</span>
                </td>
                <td className={`px-4 py-3 text-right font-semibold ${e.type === 'IN' ? 'text-success' : e.type === 'OUT' ? 'text-destructive' : 'text-foreground'}`}>
                  {e.type === 'IN' ? '+' : e.type === 'OUT' ? '-' : ''}{e.quantity}
                </td>
                <td className="px-4 py-3 text-muted-foreground text-xs hidden md:table-cell">{e.note}</td>
              </tr>
            ))}
            {filtered.length === 0 && (
              <tr><td colSpan={6} className="px-4 py-8 text-center text-muted-foreground">No records found.</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
