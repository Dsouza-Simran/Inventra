// Mock data and types for Inventra

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'staff';
}

export interface Product {
  id: string;
  name: string;
  sku: string;
  category: string;
  unit: string;
  reorderLevel: number;
  totalStock: number;
}

export interface Warehouse {
  id: string;
  name: string;
  location: string;
}

export interface StockLedgerEntry {
  id: string;
  productId: string;
  productName: string;
  warehouseId: string;
  warehouseName: string;
  toWarehouseId?: string;
  toWarehouseName?: string;
  type: 'IN' | 'OUT' | 'TRANSFER' | 'ADJUST';
  quantity: number;
  note: string;
  date: string;
}

export const CATEGORIES = ['Electronics', 'Mechanical', 'Raw Materials', 'Packaging', 'Consumables'];

export const initialProducts: Product[] = [
  { id: '1', name: 'Circuit Board A1', sku: 'CB-A1-001', category: 'Electronics', unit: 'pcs', reorderLevel: 50, totalStock: 120 },
  { id: '2', name: 'Steel Rod 10mm', sku: 'SR-10-002', category: 'Raw Materials', unit: 'kg', reorderLevel: 200, totalStock: 85 },
  { id: '3', name: 'Bearing Assembly', sku: 'BA-X3-003', category: 'Mechanical', unit: 'pcs', reorderLevel: 30, totalStock: 8 },
  { id: '4', name: 'Cardboard Box (L)', sku: 'PK-LG-004', category: 'Packaging', unit: 'pcs', reorderLevel: 100, totalStock: 340 },
  { id: '5', name: 'Solder Wire', sku: 'SW-60-005', category: 'Consumables', unit: 'm', reorderLevel: 500, totalStock: 420 },
  { id: '6', name: 'Microcontroller V2', sku: 'MC-V2-006', category: 'Electronics', unit: 'pcs', reorderLevel: 25, totalStock: 12 },
  { id: '7', name: 'Aluminum Sheet 2mm', sku: 'AS-2M-007', category: 'Raw Materials', unit: 'sheets', reorderLevel: 40, totalStock: 67 },
  { id: '8', name: 'Rubber Gasket', sku: 'RG-ST-008', category: 'Mechanical', unit: 'pcs', reorderLevel: 75, totalStock: 5 },
  { id: '9', name: 'Thermal Paste', sku: 'TP-SL-009', category: 'Consumables', unit: 'tubes', reorderLevel: 20, totalStock: 45 },
  { id: '10', name: 'Shrink Wrap Roll', sku: 'SW-RL-010', category: 'Packaging', unit: 'rolls', reorderLevel: 15, totalStock: 22 },
];

export const initialWarehouses: Warehouse[] = [
  { id: '1', name: 'Main Warehouse', location: 'Building A, Industrial Zone' },
  { id: '2', name: 'Secondary Storage', location: 'Building C, West Wing' },
  { id: '3', name: 'Cold Storage', location: 'Building B, Basement Level' },
  { id: '4', name: 'Distribution Center', location: 'Dock 7, Port Area' },
];

export const initialLedger: StockLedgerEntry[] = [
  { id: '1', productId: '1', productName: 'Circuit Board A1', warehouseId: '1', warehouseName: 'Main Warehouse', type: 'IN', quantity: 50, note: 'Supplier delivery', date: '2026-03-14T09:00:00Z' },
  { id: '2', productId: '3', productName: 'Bearing Assembly', warehouseId: '2', warehouseName: 'Secondary Storage', type: 'OUT', quantity: 20, note: 'Production order #1042', date: '2026-03-13T14:30:00Z' },
  { id: '3', productId: '5', productName: 'Solder Wire', warehouseId: '1', warehouseName: 'Main Warehouse', toWarehouseId: '2', toWarehouseName: 'Secondary Storage', type: 'TRANSFER', quantity: 100, note: 'Rebalancing stock', date: '2026-03-13T11:00:00Z' },
  { id: '4', productId: '8', productName: 'Rubber Gasket', warehouseId: '3', warehouseName: 'Cold Storage', type: 'ADJUST', quantity: -5, note: 'Damaged items removed', date: '2026-03-12T16:45:00Z' },
  { id: '5', productId: '2', productName: 'Steel Rod 10mm', warehouseId: '4', warehouseName: 'Distribution Center', type: 'IN', quantity: 300, note: 'Bulk purchase', date: '2026-03-12T08:20:00Z' },
  { id: '6', productId: '6', productName: 'Microcontroller V2', warehouseId: '1', warehouseName: 'Main Warehouse', type: 'OUT', quantity: 15, note: 'Client order #2087', date: '2026-03-11T13:10:00Z' },
  { id: '7', productId: '4', productName: 'Cardboard Box (L)', warehouseId: '2', warehouseName: 'Secondary Storage', type: 'IN', quantity: 200, note: 'Monthly restock', date: '2026-03-11T10:00:00Z' },
  { id: '8', productId: '9', productName: 'Thermal Paste', warehouseId: '1', warehouseName: 'Main Warehouse', type: 'OUT', quantity: 8, note: 'Assembly line request', date: '2026-03-10T15:30:00Z' },
];

export const chartData = [
  { name: 'Mon', in: 120, out: 80 },
  { name: 'Tue', in: 200, out: 150 },
  { name: 'Wed', in: 90, out: 110 },
  { name: 'Thu', in: 300, out: 200 },
  { name: 'Fri', in: 180, out: 260 },
  { name: 'Sat', in: 50, out: 30 },
  { name: 'Sun', in: 30, out: 20 },
];

export const categoryDistribution = [
  { name: 'Electronics', value: 132, fill: 'hsl(221, 83%, 53%)' },
  { name: 'Raw Materials', value: 152, fill: 'hsl(142, 71%, 45%)' },
  { name: 'Mechanical', value: 13, fill: 'hsl(38, 92%, 50%)' },
  { name: 'Packaging', value: 362, fill: 'hsl(280, 65%, 60%)' },
  { name: 'Consumables', value: 465, fill: 'hsl(0, 84%, 60%)' },
];
