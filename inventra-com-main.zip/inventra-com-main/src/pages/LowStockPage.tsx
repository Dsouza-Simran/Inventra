import { useInventory } from '@/hooks/useInventory';
import { AlertTriangle } from 'lucide-react';

export default function LowStockPage() {
  const { products } = useInventory();
  const lowStock = products.filter(p => p.totalStock <= p.reorderLevel);

  return (
    <div className="space-y-6 p-6 lg:p-8">
      <div className="flex items-center gap-3">
        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-destructive/10">
          <AlertTriangle className="h-5 w-5 text-destructive" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-foreground">Low Stock Alerts</h1>
          <p className="text-sm text-muted-foreground">{lowStock.length} items below reorder level. Action required.</p>
        </div>
      </div>

      {lowStock.length === 0 ? (
        <div className="rounded-xl border border-border bg-card p-12 text-center shadow-inventra">
          <p className="text-lg font-medium text-foreground">All clear!</p>
          <p className="text-sm text-muted-foreground">No products are below their reorder level.</p>
        </div>
      ) : (
        <div className="overflow-x-auto rounded-xl border border-border bg-card shadow-inventra">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border">
                <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-muted-foreground">Product</th>
                <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-muted-foreground">SKU</th>
                <th className="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wider text-muted-foreground">Current Stock</th>
                <th className="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wider text-muted-foreground">Reorder Level</th>
                <th className="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wider text-muted-foreground">Deficit</th>
              </tr>
            </thead>
            <tbody>
              {lowStock.map(p => (
                <tr key={p.id} className="border-b border-border last:border-0 hover:bg-destructive/5 transition-colors">
                  <td className="px-4 py-3 font-medium text-foreground">{p.name}</td>
                  <td className="px-4 py-3 text-muted-foreground font-mono text-xs">{p.sku}</td>
                  <td className="px-4 py-3 text-right font-semibold text-destructive">{p.totalStock} {p.unit}</td>
                  <td className="px-4 py-3 text-right text-muted-foreground">{p.reorderLevel} {p.unit}</td>
                  <td className="px-4 py-3 text-right font-semibold text-destructive">-{p.reorderLevel - p.totalStock} {p.unit}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
