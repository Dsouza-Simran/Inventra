import { Package, Warehouse, LayoutDashboard, ScrollText, AlertTriangle, ArrowLeftRight, LogOut, Menu } from 'lucide-react';
import { NavLink } from '@/components/NavLink';
import { useAuth } from '@/hooks/useAuth';
import { useNavigate } from 'react-router-dom';
import { useState } from 'react';

const navItems = [
  { title: 'Dashboard', url: '/dashboard', icon: LayoutDashboard },
  { title: 'Products', url: '/products', icon: Package },
  { title: 'Warehouses', url: '/warehouses', icon: Warehouse },
  { title: 'Operations', url: '/operations', icon: ArrowLeftRight },
  { title: 'Stock Ledger', url: '/ledger', icon: ScrollText },
  { title: 'Low Stock', url: '/low-stock', icon: AlertTriangle },
];

export function AppSidebar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [collapsed, setCollapsed] = useState(false);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <>
      {/* Mobile overlay */}
      {!collapsed && (
        <div className="fixed inset-0 z-30 bg-foreground/20 lg:hidden" onClick={() => setCollapsed(true)} />
      )}
      
      <aside className={`fixed lg:sticky top-0 left-0 z-40 h-screen flex flex-col border-r border-border bg-card transition-all duration-200 ${collapsed ? '-translate-x-full lg:translate-x-0 lg:w-16' : 'w-64'}`}>
        {/* Logo */}
        <div className="flex h-14 items-center gap-2 border-b border-border px-4">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
            <Package className="h-4 w-4 text-primary-foreground" />
          </div>
          {!collapsed && <span className="text-base font-bold tracking-tight text-foreground">Inventra</span>}
        </div>

        {/* Nav */}
        <nav className="flex-1 space-y-1 p-3">
          {navItems.map((item) => (
            <NavLink
              key={item.url}
              to={item.url}
              end
              className="flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
              activeClassName="bg-primary/10 text-primary hover:bg-primary/10 hover:text-primary"
            >
              <item.icon className="h-4 w-4 shrink-0" />
              {!collapsed && <span>{item.title}</span>}
            </NavLink>
          ))}
        </nav>

        {/* User */}
        <div className="border-t border-border p-3">
          {!collapsed && user && (
            <div className="mb-2 px-3">
              <p className="text-sm font-medium text-foreground truncate">{user.name}</p>
              <p className="text-xs text-muted-foreground capitalize">{user.role}</p>
            </div>
          )}
          <button onClick={handleLogout} className="flex w-full items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium text-muted-foreground transition-colors hover:bg-destructive/10 hover:text-destructive">
            <LogOut className="h-4 w-4 shrink-0" />
            {!collapsed && <span>Logout</span>}
          </button>
        </div>
      </aside>

      {/* Mobile trigger */}
      <button onClick={() => setCollapsed(!collapsed)} className="fixed bottom-4 right-4 z-50 flex h-12 w-12 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-lg lg:hidden">
        <Menu className="h-5 w-5" />
      </button>

      {/* Desktop collapse toggle */}
      <button onClick={() => setCollapsed(!collapsed)} className="hidden lg:flex fixed top-3 left-2 z-50 h-8 w-8 items-center justify-center rounded-md text-muted-foreground hover:bg-secondary" style={collapsed ? {} : { left: '232px' }}>
        <Menu className="h-4 w-4" />
      </button>
    </>
  );
}
