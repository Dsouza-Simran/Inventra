import React, { createContext, useContext, useState, useCallback } from 'react';
import { initialProducts, initialWarehouses, initialLedger, type Product, type Warehouse, type StockLedgerEntry } from '@/lib/data';

interface InventoryContextType {
  products: Product[];
  warehouses: Warehouse[];
  ledger: StockLedgerEntry[];
  addProduct: (p: Omit<Product, 'id'>) => void;
  updateProduct: (p: Product) => void;
  deleteProduct: (id: string) => void;
  addWarehouse: (w: Omit<Warehouse, 'id'>) => void;
  updateWarehouse: (w: Warehouse) => void;
  deleteWarehouse: (id: string) => void;
  adjustStock: (entry: Omit<StockLedgerEntry, 'id' | 'date'>) => void;
}

const InventoryContext = createContext<InventoryContextType | undefined>(undefined);

export const InventoryProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [products, setProducts] = useState<Product[]>(initialProducts);
  const [warehouses, setWarehouses] = useState<Warehouse[]>(initialWarehouses);
  const [ledger, setLedger] = useState<StockLedgerEntry[]>(initialLedger);

  const addProduct = useCallback((p: Omit<Product, 'id'>) => {
    setProducts(prev => [...prev, { ...p, id: Date.now().toString() }]);
  }, []);

  const updateProduct = useCallback((p: Product) => {
    setProducts(prev => prev.map(x => x.id === p.id ? p : x));
  }, []);

  const deleteProduct = useCallback((id: string) => {
    setProducts(prev => prev.filter(x => x.id !== id));
  }, []);

  const addWarehouse = useCallback((w: Omit<Warehouse, 'id'>) => {
    setWarehouses(prev => [...prev, { ...w, id: Date.now().toString() }]);
  }, []);

  const updateWarehouse = useCallback((w: Warehouse) => {
    setWarehouses(prev => prev.map(x => x.id === w.id ? w : x));
  }, []);

  const deleteWarehouse = useCallback((id: string) => {
    setWarehouses(prev => prev.filter(x => x.id !== id));
  }, []);

  const adjustStock = useCallback((entry: Omit<StockLedgerEntry, 'id' | 'date'>) => {
    const newEntry: StockLedgerEntry = {
      ...entry,
      id: Date.now().toString(),
      date: new Date().toISOString(),
    };
    setLedger(prev => [newEntry, ...prev]);

    // Update product stock
    setProducts(prev => prev.map(p => {
      if (p.id === entry.productId) {
        const adj = entry.type === 'IN' ? entry.quantity : entry.type === 'OUT' ? -entry.quantity : entry.type === 'ADJUST' ? entry.quantity : 0;
        return { ...p, totalStock: Math.max(0, p.totalStock + adj) };
      }
      return p;
    }));
  }, []);

  return (
    <InventoryContext.Provider value={{ products, warehouses, ledger, addProduct, updateProduct, deleteProduct, addWarehouse, updateWarehouse, deleteWarehouse, adjustStock }}>
      {children}
    </InventoryContext.Provider>
  );
};

export const useInventory = () => {
  const ctx = useContext(InventoryContext);
  if (!ctx) throw new Error('useInventory must be used within InventoryProvider');
  return ctx;
};
